<?php include 'header.php' ?>    
<body>
    <!-- container -->
    <div class="container">

        <center><div class="alert alert-info"> 
        Desculpe, seu navegador não é compatível com este site! <br>
Faça o download de um dos seguintes navegadores:<br>
        </div>
        <a class="btn btn-primary" href="https://www.google.com/chrome/"><i class="fab fa-chrome"></i> Chrome</a><br><br>
        <a class="btn btn-primary" href="https://www.mozilla.org/en-US/firefox/new/"><i class="fab fa-firefox"></i> Firefox</a><br><br>
        <a class="btn btn-primary" href="https://support.apple.com/downloads/safari-for-windows"><i class="fab fa-safari"></i> Safari</a><br><br>
        </center>
        <br><br>
        

    </div><!-- ./ container -->
        
    <!-- Footer -->
    <?php include 'footer.php' ?>
</body>
</html>
